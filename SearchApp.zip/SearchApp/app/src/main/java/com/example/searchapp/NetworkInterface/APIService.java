package com.example.searchapp.NetworkInterface;

import com.example.searchapp.data.ItunesData;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface APIService {
    @GET("/search")
    Observable<ItunesData> getItuneData(@Query("term") String name);
}
