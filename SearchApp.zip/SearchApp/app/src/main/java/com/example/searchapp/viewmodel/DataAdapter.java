package com.example.searchapp.viewmodel;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.searchapp.R;
import com.example.searchapp.data.Result;
import com.squareup.picasso.Picasso;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private List<Result> dataList;
    private Context context;

    public DataAdapter(List<Result>dataList, Context context)
    {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.data_card_view,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        viewHolder.txtName.setText(dataList.get(i).getArtistName());
        viewHolder.txtDistance.setText(dataList.get(i).getKind());
        viewHolder.txtGravity.setText(dataList.get(i).getTrackName());
        viewHolder.txtDiameter.setText(dataList.get(i).getCountry());
        Picasso.with(context)
                .load(dataList.get(i).getArtworkUrl100())
                .placeholder(R.drawable.ic_launcher_background)
                .fit()
                .into(viewHolder.imageView);

    }



    @Override
    public int getItemCount() {
        if(dataList != null)
        return dataList.size();
        else
         return 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtName, txtDistance, txtGravity, txtDiameter;
        ImageView imageView;
        CardView cv;

        ViewHolder(View itemView) {
            super(itemView);

            cv = itemView.findViewById(R.id.menu_toolbarsearch);
            imageView = itemView.findViewById(R.id.imageView);
            txtName = itemView.findViewById(R.id.txtName);
            txtDistance = itemView.findViewById(R.id.txtDistance);
            txtGravity = itemView.findViewById(R.id.txtGravity);
            txtDiameter = itemView.findViewById(R.id.txtDiameter);

        }
    }
}
