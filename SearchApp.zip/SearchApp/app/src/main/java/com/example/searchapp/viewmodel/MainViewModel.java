package com.example.searchapp.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import com.example.searchapp.NetworkInterface.APIService;
import com.example.searchapp.NetworkInterface.NetworkBuilder;
import com.example.searchapp.data.ItunesData;
import com.example.searchapp.data.Result;
import java.io.File;
import java.util.List;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;

public class MainViewModel extends ViewModel {

    private File file;
    private MutableLiveData<List<Result>> data  = new MutableLiveData<>();

    public LiveData<List<Result>> getUsers(File file, String query) {

            this.file = file;
            loadUsers(query);

        return data;
    }

    private void loadUsers(String query) {

        Retrofit retrofit = NetworkBuilder.getInstance().setupRetrofitAndOkHttp(file);
        APIService apiService = retrofit.create(APIService.class);
        final Observable<ItunesData> ituneData =  apiService.getItuneData(query);
       ituneData
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ItunesData>() {
                    @Override
                    public void onSubscribe(Disposable d) {}

                    @Override
                    public void onNext(ItunesData itunesData) {

                        data.setValue(itunesData.getResults());

                    }

                    @Override
                    public void onError(Throwable e) {}

                    @Override
                    public void onComplete() {}
                });
    }




}
