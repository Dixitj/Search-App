package com.example.searchapp.view;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;
import com.example.searchapp.R;
import com.example.searchapp.viewmodel.DataAdapter;
import com.example.searchapp.viewmodel.MainViewModel;
import java.io.File;
import java.util.Objects;


public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{

    Toolbar tbMainSearch;
    MainViewModel mainViewModel;
    RecyclerView recyclerView;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        initViews();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_search, menu);
        MenuItem mSearchmenuItem = menu.findItem(R.id.menu_toolbarsearch);
        searchView = (SearchView) mSearchmenuItem.getActionView();
        searchView.setQueryHint(getString(R.string.enter_value));
        searchView.setOnQueryTextListener(this  );
        mSearchmenuItem.getActionView();
        return true;

    }



    @Override
    public boolean onQueryTextSubmit(String query) {

        hideKeyboard();

        if(haveNetworkConnection()) {
            mainViewModel.getUsers(new File(getCacheDir(), "offlineCache"), query)
                    .observe(this,results -> {

            if (results!= null && results.size() != 0) {

                recyclerView.setVisibility(View.VISIBLE);
                recyclerView.setHasFixedSize(true);
                recyclerView.setAdapter(new DataAdapter(results.subList(0,results.size()),this));
                recyclerView.setLayoutManager(new LinearLayoutManager(this));

                recyclerView.setItemAnimator(new DefaultItemAnimator());
                searchView.clearFocus();

            } else
                Toast.makeText(this,getString(R.string.no_data),Toast.LENGTH_LONG).show(); });

        }else
            Toast.makeText(this,getString(R.string.no_internet),Toast.LENGTH_LONG).show();

         return true;
    }


    @Override
    public boolean onQueryTextChange(String newText) {
        return false;
    }

    private void initViews(){
        recyclerView = findViewById(R.id.dataRecyclerView);
        tbMainSearch = findViewById(R.id.tb_toolbarsearch);
        setSupportActionBar(tbMainSearch);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

    }


    private boolean haveNetworkConnection() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo
                .isConnectedOrConnecting();
    }

    private void hideKeyboard() {
        InputMethodManager inputManager = (InputMethodManager) getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(Objects
                .requireNonNull(this.getCurrentFocus()).getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }
}
